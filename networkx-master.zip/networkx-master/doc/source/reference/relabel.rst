****************
Relabeling nodes
****************
.. currentmodule:: networkx

Relabeling
----------
.. automodule:: networkx.relabel

.. autosummary::
   :toctree: generated/

   convert_node_labels_to_integers
   relabel_nodes


