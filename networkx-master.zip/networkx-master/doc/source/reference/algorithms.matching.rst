********
Matching
********

.. automodule:: networkx.algorithms.matching
.. autosummary::
   :toctree: generated/

   is_matching
   is_maximal_matching
   maximal_matching
   max_weight_matching
