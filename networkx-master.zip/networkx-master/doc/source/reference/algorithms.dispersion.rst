**********
Dispersion
**********

.. automodule:: networkx.algorithms.dispersion

   Dispersion
----------
.. autosummary::
   :toctree: generated/

   dispersion
